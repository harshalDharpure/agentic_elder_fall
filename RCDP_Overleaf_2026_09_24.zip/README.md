# RCDP — Confidence-Gated Multi-Agent Fall Detection (LaTeX package)

Self-contained IEEEtran manuscript. Target venue: IEEE J. Biomedical and Health
Informatics (Q1) or IEEE Trans. Neural Systems and Rehabilitation Engineering.

## Current status (2026-09-24)

The target journal is not yet selected. The revised draft incorporates supplied
per-fold counts, a five-fold backbone table and matched always-fall controls.
Classification and timing runs are separate. No local LaTeX compilation was
performed; the author will review the PDF in Overleaf.

The current checklist is [RESULTS_RECONCILIATION.md](RESULTS_RECONCILIATION.md).
Earlier review/planning documents are historical and do not supersede it.

## Folder map

| Path | Contents |
|------|----------|
| `main.tex` | Full manuscript (IEEEtran journal) |
| `refs.bib` | Bibliography — 55 entries, all cited, DOIs where verified |
| `tables/` | One `.tex` per table, all `\input` from `main.tex` |
| `figures/` | TikZ sources (`.tex`) + rendered plots (`.pdf`) |
| `algorithms/` | Algorithms 1–2 |
| `results_text/` | Text summaries, transcribed CSV records and provenance history |
| `check_manuscript.py` | Structural pre-flight (no LaTeX needed) |
| `check_numbers.py` | Recomputes every `Mean` row from its per-fold rows |
| `check_reported_results.py` | Checks supplied counts and selected aggregates; derives matched constant controls |
| `recompute_ci.py` | Regenerates every bootstrap CI from the per-fold tables |
| `recover_confusion.py` | Recovers confusion matrices by integer search |
| `IEEEtran.cls` / `.bst` | Local copies (Overleaf also provides these) |

## Pre-flight (run before every compile)

```bash
python check_manuscript.py   # inputs, refs/labels, cite keys, braces, table arity
python check_numbers.py      # available Mean rows (76 cells)
python check_reported_results.py # supplied counts and selected aggregates
```

All must print `OK`. `check_numbers.py` is what catches the most dangerous
class of error in this paper: a re-run that updates per-fold rows but leaves a
stale aggregate behind.

After any re-run that changes a per-fold number, also regenerate the derived
quantities so they cannot drift from the tables:

```bash
python recompute_ci.py       # -> intervals in tab_stats / tab_kfall_mean
python recover_confusion.py  # historical reconstruction; supplied counts now primary
```

## Compile

Overleaf: upload the folder, set main document to `main.tex`, compiler
**pdfLaTeX**, recompile twice after the first BibTeX pass.

## Figures

Three figures are pure TikZ and compile from source — edit the `.tex`, not a PDF:

| File | Role |
|------|------|
| `figures/architecture.tex` | Fig. 1 — dual-process architecture (System 1 / System 2 bands) |
| `figures/gate_band.tex` | Fig. 2 — decision geometry of the dual-threshold gate |
| `figures/latency_timeline.tex` | Fig. 3 — log-scale latency budget of both tiers |

Each is wrapped in `\resizebox{\linewidth}{!}{...}` in `main.tex`, so they fit
the column exactly regardless of natural size.

`figures/deployment_architecture.{tex,pdf}` is **superseded** by Fig. 1 and is
no longer included; it is kept only for reference.

The five rendered plots are retained from the existing package. The originating
pipeline is not included here. Inspect their labels and consistency in Overleaf;
textual validation does not inspect rendered plot content.

## Ground-truth numbers

`results_text/DATA_LOCK.txt`. Do not invent metrics. If a re-run changes a
per-fold number, update the table and re-run `check_numbers.py`.

## Authors

The anonymous block is a placeholder. Confirm the journal's review policy before
deciding whether to anonymise. Supply authors, affiliations, funding, conflicts
and institutional ethics statements as required.

## Outstanding pre-submission items

See [RESULTS_RECONCILIATION.md](RESULTS_RECONCILIATION.md). Some items require
configuration artifacts or author declarations, not new experiments. Stronger
LLM-necessity, cross-backbone and deployment claims require additional evidence.
