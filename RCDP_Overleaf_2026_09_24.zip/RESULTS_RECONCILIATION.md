# Submission preparation and evidence reconciliation

Updated 2026-09-24 after the author supplied per-fold numerical tables. No experiment was rerun and no LaTeX compilation was performed. Arithmetic checks do not independently verify predictions or clinical validity. The target journal remains undecided.

## Resolved from supplied records

| Issue | Resolution |
|---|---|
| Primary ablations | Main-ablation counts reproduce Tier-1 F1 0.758560 and stack 0.886929, mean costs 1150.8 and 199.8. `gate_knn` reproduces F1 0.752549, recall 0.723168, cost 1286.0. Each method contributes once per fold. |
| Alternative 0.877±0.071 / 208 summary | Not the aggregate of the five main-ablation records. The extended-mode list contains repeated folds and different baseline/rerun values. Do not reinterpret it as the primary estimate or assert that duplicates alone explain its exact value. Its full provenance still needs manifests. |
| Precision/specificity mismatch | The separate agentic timing run has FP 101/62/108 in folds 1/3/4 versus primary FP 100/63/106. Its 0.038/0.040 stds belong to that run. Primary precision is 0.813165±0.036375 and specificity 0.827539±0.038836, printed as 0.813±0.036 and 0.828±0.039. |
| Confusion counts | Supplied main-ablation counts confirm the earlier reconstruction. Attribute them to author-supplied aggregates, not independently inspected prediction files. |
| G1 | Separate E1/retrained five-fold table now replaces archived single-fold context. A v2 table reports 0.751±0.039 on 30,000 windows/fold; neither replaces the primary baseline. |
| G2 costs | Computed from counts: GBM 1366.25/1000, always-fall 311.25/1000 on 160 escalated cases/fold. |
| Matched LLM constant control | Derived from the LLM set's own class totals (150/fold): always-fall F1 0.789776±0.028433, cost 346.67/1000; Mistral F1 0.972216±0.009878, cost 37.33/1000. Qwen also improves on always-fall; it is not the same rule. |
| Statistics | SisFall intervals use counts before rounding. Recall percentile interval is [0.187, 0.248]. Fold-bootstrap intervals are descriptive; p=0.0625 does not meet 0.05. |

## Remaining author-dependent requirements before submission

1. **Choose the journal and confirm its current instructions.** Supply authors/affiliations, corresponding author, funding, conflicts and contributions. Confirm review/anonymisation policy; the anonymous block is a placeholder. Review page limits, figures and table placement in Overleaf.
2. **Supply methods/configuration artifacts.** Subject train/calibration/test manifests; exact channels and sampling/resampling/units; window labels and transition treatment; feature formulas; training-only normalization; optimizer/scheduler/epochs/early stopping; class weights, mixup and sampler; held-out threshold selection for Youden/max-F1/cost; gate grid, penalty and tie rule; G2 subject isolation, hyperparameters and thresholds; evidence/retrieval equality across adjudicators.
3. **Supply inference details.** Exact serializer, MiniLM model/digest, prompts, retrieval IDs, LLM digests/quantisation, Ollama version, decoding temperature/seed/token limits, malformed-JSON/time-out handling, GPU/CPU/RAM and timing procedure. A mutable model tag is insufficient. Verify the descriptive pseudocode against the actual implementation, including conformal empty-set handling and tie-breaking.
4. **Package supporting exports.** The supplied paths refer to an external Linux results tree, not accessible locally. Include prediction files/configurations or a stable permitted archive. Confirm the main-ablation run is the intended primary run and document how it was selected; do not pool repeated extended-mode records as independent folds.
5. **Verify action evaluation and ethics.** Supply the four-action cost matrix/severity mapping, grounding scoring procedure/denominators and any raters/agreement. Confirm secondary-data ethics requirements and licenses with the responsible institution. Do not claim unrecorded approval or clinical validation.

These are missing methods and author declarations, not facts that can be invented through editing. Stating the limitations does not complete those requirements.

## Additional experiments for stronger claims

- Matched cost-tuned GBM/logistic versus Mistral, with identical cases and evidence, is absent. The new matched constant control does not resolve this. Do not claim LLM necessity or efficiency superiority over feature classifiers.
- Per-backbone D18/D19 metrics and complete cross-backbone wrapper evaluation remain absent. Partial `+agentic` rows do not establish a matched full-stack evaluation for all backbones/folds.
- Prospective older-adult evaluation, event-level false alarms/hour, embedded energy and streaming queueing tests are required for deployment claims, not for a narrowly scoped retrospective description.

## Reproducible local arithmetic

- [results_text/reported_counts.csv](results_text/reported_counts.csv): 80 transcribed count rows across four evaluations, not prediction-level data.
- [results_text/backbone_f1.csv](results_text/backbone_f1.csv): nine backbones with five folds each for E1 and retraining.
- [results_text/g1_v2.csv](results_text/g1_v2.csv): separate v2 detector folds.
- [check_reported_results.py](check_reported_results.py): verifies totals, class totals, selected aggregates and confusion rows; derives the matched constant control.
- [recompute_ci.py](recompute_ci.py): reads SisFall counts and displayed KFall folds rather than hard-coded primary metric arrays.

**Readiness:** numerically reconciled submission-preparation draft; author methods, artifact release and journal-specific checks remain incomplete. No acceptance guarantee is implied.